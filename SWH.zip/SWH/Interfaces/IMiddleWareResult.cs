﻿using LunaHost.HTTP.Interface;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LunaHost.Interfaces
{

    public interface IMiddleWareResult<out T1> where T1 : IHttpResponse
    {
        T1 Response { get;  }
        bool Success { get;  }
      
    }

}
